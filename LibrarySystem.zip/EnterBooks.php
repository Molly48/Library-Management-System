<?php
include "headeradmin.php";
?>

<br><br><br>

<!DOCTYPE HTML>
<html>

<style>
		body {
			margin: 0;
			padding: 0;
			font-family: 'Jost', sans-serif;
			background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
			background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
			background-repeat: no-repeat;
			background-position: center;
			background-size: cover;
			height: 100vh;
		}

		table {
			background-color: lightgoldenrodyellow;
		}
	</style>

<body>

	<form action="InsertBooks.php" method="post">
		<table border="2" align="center" cellpadding="20" cellspacing="">
			<tr>
			<td>Book Id  :</td>
			<td> <input type="text" name="book_id" size="48"> </td>
			</tr>
			<tr>
			<td>Book Title :</td>
			<td> <input type="text" name="book_title" size="48"> </td>
			</tr>
			<tr>
			<td>Author :</td>
			<td> <input type="text" name="author" size="48"> </td>
			</tr>
			<tr>
			<td>No.of Copies :</td>
			<td> <input type="text" name="no_of_copy" size="48"> </td>
			</tr>
			<td>
			<input type="submit" value="Add">
			<input type="Reset" value="Reset">
			</td>
			</tr>
		</table>
	</form>

</body>
</html>