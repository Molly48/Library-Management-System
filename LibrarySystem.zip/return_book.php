<?php
session_start();
include("DBConnection.php");

if (isset($_GET['bookId'])) {
    $bookId = $_GET['bookId'];

    // Check if the book is eligible for returning
    $query = "SELECT no_of_copy FROM books WHERE book_id = '$bookId'";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    $noOfCopy = $row['no_of_copy'];

    if ($noOfCopy < 5) {
        // Increase the number of copies by 1
        $query = "UPDATE books SET no_of_copy = no_of_copy + 1 WHERE book_id = '$bookId'";
        mysqli_query($db, $query);

        // Retrieve the user ID from the session
        $username = $_SESSION['username'];
        $userQuery = "SELECT id FROM user WHERE username = '$username'";
        $userResult = mysqli_query($db, $userQuery);
        $userRow = mysqli_fetch_assoc($userResult);
        $userId = $userRow['id'];

        // Delete the oldest borrowed record with the given book ID and user ID
        $deleteQuery = "DELETE FROM borrow WHERE bookid = '$bookId' AND userid = '$userId' ORDER BY id ASC LIMIT 1";
        mysqli_query($db, $deleteQuery);

        // Redirect back to the book list page
        header("Location: userbook2.php");
        exit();
    } else {
        echo "All copies of the book have been returned.";
    }
}
?>
