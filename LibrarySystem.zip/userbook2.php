<?php
session_start();
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: userlogin.php"); // Redirect to the login page
    exit(); // Stop executing the rest of the code
  }

$username = $_SESSION['username'];
// echo "Logged in as: " . $username;

include "atasuser.php";
include "DBConnection.php";
?>

<!DOCTYPE HTML>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Jost', sans-serif;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
            background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            height: 100vh;
        }

        table {
            background-color: pink;
        }
    </style>
</head>

<body>
    <br>
    <?php
        $search = isset($_REQUEST["search"]) ? $_REQUEST["search"] : "";
        $query = "SELECT books.book_id, books.book_title, books.author, books.no_of_copy, borrow.userid 
                FROM books LEFT JOIN borrow ON books.book_id = borrow.bookid AND borrow.userid = (SELECT id FROM user WHERE username = '$username') WHERE books.book_id LIKE '%$search%'";
        $result = mysqli_query($db, $query);
        if (mysqli_num_rows($result) > 0) {
    ?>

    <table border="2" align="center" cellpadding="10" cellspacing="10">
        <tr>
            <th>Book Id</th>
            <th>Book Title</th>
            <th>Author</th>
            <th>No of copy</th>
            <th colspan="2">Actions</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr id="<?php echo $row["book_id"]; ?>">
                <td><?php echo $row["book_id"]; ?></td>
                <td><?php echo $row["book_title"]; ?></td>
                <td><?php echo $row["author"]; ?></td>
                <td><?php echo $row["no_of_copy"]; ?></td>
                <td>
                <?php if ($row["no_of_copy"] > 0) {
                    $bookId = $row["book_id"];
                    $checkQuery = "SELECT * FROM borrow WHERE userid = (SELECT id FROM user WHERE username = '$username') AND bookid = '$bookId'";
                    $checkResult = mysqli_query($db, $checkQuery);
                    if (mysqli_num_rows($checkResult) == 0) { 
                        ?>
                        <a href="borrow_book.php?bookId=<?php echo $row["book_id"]; ?>">Borrow</a>
                    <?php } else { ?>
                        <span style="color: green;">Already borrowed</span>
                    <?php }
                } else { ?>
                    <span style="color: red;">Out of stock</span>
                <?php } ?>
                </td>
                <td>
                    <?php if (empty($row["userid"])) { ?>
                        <span style="color: green;">All copies returned</span>
                    <?php } elseif ($row["no_of_copy"] < 5 && !empty($row["userid"])) { ?>
                        <a href="return_book.php?bookId=<?php echo $row["book_id"]; ?>">Return</a>
                    <?php } elseif ($row["no_of_copy"] == 5) { ?>
                        <span style="color: green;">All copies returned</span>
                    <?php } ?>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
    <?php
} else {
    echo "<center>No records found with ID: $search</center>";
}
?>
</body>
</html>