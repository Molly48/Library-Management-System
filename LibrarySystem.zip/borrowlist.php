<?php
session_start(); // Start the session
include "headeradmin.php";
include "DBConnection.php";
?>

<!DOCTYPE HTML>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Jost', sans-serif;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
            background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            height: 100vh;
        }

        table {
            background-color: lightgoldenrodyellow;
        }
    </style>
</head>

<body>
    <br>
    <?php
    $search = isset($_REQUEST["search"]) ? $_REQUEST["search"] : "";

    $query = "SELECT borrow.id, user.username, books.book_title FROM borrow
              INNER JOIN user ON borrow.userid = user.id
              INNER JOIN books ON borrow.bookid = books.book_id
              WHERE books.book_title LIKE '%$search%'";

    $result = mysqli_query($db, $query);
    if (mysqli_num_rows($result) > 0) {
?>

    <table border="2" align="center" cellpadding="5" cellspacing="5">
        <tr>
            <th>No.</th>
            <th>Username</th>
            <th>Book Title</th>
        </tr>

        <?php
            $counter = 1; // Initialize the counter variable
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
            <tr>
                <td><?php echo $counter++; ?></td>
                <td><?php echo $row["username"];?></td>
                <td><?php echo $row["book_title"];?></td>
            </tr>
        <?php } ?>

    </table>

    <?php
    } else {
        echo "<center>No records found with ID: $search</center>";
    }
    ?>

</body>
</html>
