<?php
include "headeradmin.php";
include "DBConnection.php";
?>

<br><br><br>

<!DOCTYPE HTML>
<html>
<body>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Jost', sans-serif;
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        height: 100vh;
    }

    table {
        background-color: lightgoldenrodyellow;
    }
</style>

<form action="InsertUser.php" method="post">

    <table border="2" align="center" cellpadding="20" cellspacing="">
        <tr>
            <td>Username:</td>
            <td><input type="text" name="username" size="48"></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="text" name="password" size="48"></td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" value="Add">
                <input type="reset" value="Reset">
            </td>
        </tr>
    </table>
</form>
</body>
</html>
