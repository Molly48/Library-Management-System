<?php
include("DBConnection.php");

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM user WHERE id = '$id'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "User deleted successfully.";
        // Redirect to the display page after deletion
        header("Location: DisplayUser.php");
        exit;
    } else {
        echo "Error deleting user.";
    }
} else {
    echo "Invalid user ID.";
}
?>


