<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<style>
  nav {
    background-color: #993333;
    padding: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .logo {
    display: flex;
    align-items: center;
  }

  .logo img {
    height: 60px;
    margin-right: 10px;
  }

  .logo h1 {
    color: #fff;
  }

  .menu {
    list-style-type: none;
    margin: 0;
    padding: 0;
    display: flex;
  }

  .menu li {
    margin-left: 10px;
  }

  .menu li a {
    text-decoration: none;
    color: #fff;
    padding: 5px;
    font-weight: bold;
    font-size: 20px;
  }

  .menu li a:hover {
    color: #666;
  }
</style>

<body>
  <nav>
    <div class="logo">
      <img src="https://www.pngfind.com/pngs/m/110-1104400_circle-icons-bookshelf-library-icon-png-transparent-png.png" alt="Logo">
      <h1>R & A's LIBRARY</h1>
    </div>
    <ul class="menu">
     
      <li><a href="userlogin.php">USER LOGIN</a></li>
      <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
    </ul>
  </nav>
</body>
</html>
