<?php
include 'mainheader.php';
?>

<!DOCTYPE html>

<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<style>

body {
        margin: 0;
        padding: 0;
        font-family: 'Jost', sans-serif;
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        height: 100vh; 
    }


.container {
    position: relative;
    height: 80%;
}

.bg-text {
    background-color: rgb(0,0,0); 
    background-color: rgba(0,0,0, 0.4); 
    color: white;
    font-weight: bold;
    border: 3px solid #f1f1f1;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2;
    width: 80%;
    padding: 20px;
    text-align: center;
}

.welcome-text {
    position: absolute;
    left: 50%;
    top: 8%;
    transform: translateX(-50%);
    font-size: 80px;
    color: white;
    font-weight: bold;
    text-shadow: -1px -1px 0 black, 1px -1px 0 black, -1px 1px 0 black, 1px 1px 0 black;
    text-align: center;
}

.buttons-container {
    position: absolute;
    left: 50%;
    bottom: 100px;
    transform: translateX(-50%);
    z-index: 2;
}

.button {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px;
    font-size: 18px;
    color: white;
    background-color: #CD5C5C;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

</style>

<div class="container">

    <div class="bg-image"></div>

    <div class="bg-text">
        <h1 style="font-size:30px">"You know you've read a good book when you turn the last page and feel a little as if you have lost a friend"</h1>
    </div>

    <div class="welcome-text">
        <h1 style="font-size:50px">WELCOME TO R & A's LIBRARY</h1>
    </div>

</div>

</body>
</html>

