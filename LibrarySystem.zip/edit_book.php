<?php
include "headeradmin.php";
?>

<center>

<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Jost', sans-serif;
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
    }

        .container {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		height: 100vh;
		margin: 0;
		padding: 0;
		font-family: 'Jost', sans-serif;
		background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
		background-image: url('');
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.main {
		width: 500px;
		height: 650px;
		background: #993333;
		overflow: hidden;
		border-radius: 10px;
		box-shadow: 5px 20px 50px #000;
	}

	#chk{
	display: none;
}
.signup{
	position: relative;
	width:100%;
	height: 100%;
}
label{
	color: #fff;
	font-size: 1.5 em;
	justify-content: center;
	display: flex;
	margin: 20px;
	font-weight: bold;
	cursor: pointer;
	transition: .5s ease-in-out;
}
input{
	width: 60%;
	height: 20px;
	background: #e0dede;
	justify-content: center;
	display: flex;
	margin: 20px auto;
	padding: 10px;
	border: none;
	outline: none;
	border-radius: 5px;
}
button{
	width: 60%;
	height: 40px;
	margin: 10px auto;
	justify-content: center;
	display: block;
	color: #fff;
	background: #573b8a;
	font-size: 1em;
	font-weight: bold;
	margin-top: 20px;
	outline: none;
	border: none;
	border-radius: 5px;
	transition: .2s ease-in;
	cursor: pointer;
}
button:hover{
	background: #6d44b8;
}
.login{
	height: 460px;
	background: #eee;
	border-radius: 60% / 10%;
	transform: translateY(-180px);
	transition: .8s ease-in-out;
}
.login label{
	color: #573b8a;
	transform: scale(.6);
}

#chk:checked ~ .login{
	transform: translateY(-500px);
}
#chk:checked ~ .login label{
	transform: scale(1);	
}
#chk:checked ~ .signup label{
	transform: scale(.6);
}
</style>

<?php
include("DBConnection.php");

if (isset($_POST['submit'])) {
    $book_id = $_POST['book_id'];
    $newTitle = $_POST['new_title'];
    $author = $_POST['author'];
    $no_of_copy = $_POST['no_of_copy'];

    $query = "UPDATE books SET book_title = '$newTitle', author = '$author', no_of_copy = '$no_of_copy' WHERE book_id = '$book_id'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "Book information updated successfully.";
        header("Location: DisplayBooks.php");
        exit;
    } else {
        echo "Error updating book information.";
    }
}

if(isset($_GET['title'])) {
    $title = $_GET['title'];

    $query = "SELECT * FROM books WHERE book_id = '$title'";
    $result = mysqli_query($db, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $bookTitle = $row['book_title'];
        $author = $row['author'];
        $noOfCopy = $row['no_of_copy'];
        ?>

        <div class="container">
            <div class="main">
                <h1>Edit Book</h1>
                <form method="post" action="update_book.php">
                    <input type="hidden" name="title" value="<?php echo $title; ?>">
                    <label for="book_title">Book Title:</label>
                    <input type="text" name="book_title" id="book_title" value="<?php echo $bookTitle; ?>"><br><br>
                    <label for="author">Author:</label>
                    <input type="text" name="author" id="author" value="<?php echo $author; ?>"><br><br>
                    <label for="no_of_copy">No of Copy:</label>
                    <input type="text" name="no_of_copy" id="no_of_copy" value="<?php echo $noOfCopy; ?>"><br><br>
                    <input type="submit" name="submit" value="Update">
                </form>
            </div>
        </div>

        <?php
    } else {
        echo "Book not found.";
    }
} else {
    echo "Invalid book title.";
}
  
?>

<script src="path_to_your_script.js"></script>

</center>
