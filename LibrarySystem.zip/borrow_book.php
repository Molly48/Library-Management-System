<?php
session_start();

// User is logged in
$username = $_SESSION['username'];
// echo "Logged in as: " . $username;

include("DBConnection.php");


if (!isset($_GET['bookId'])) {
  
    header("Location: userbook2.php");
    exit();
}


$bookId = $_GET['bookId'];


// Retrieve the book information from the database
$sql = "SELECT * FROM books WHERE book_id = '$bookId'";
$result = mysqli_query($db, $sql);

if (!$result || mysqli_num_rows($result) == 0) {

    echo "Error: Book not found.";
} else {
    $row = mysqli_fetch_assoc($result);
    $title = $row['book_title'];
    

    // Check if the book is available for borrowing
    if ($row['no_of_copy'] > 0) {
 
        $bookId = $row['book_id'];
        
        $query = "SELECT id FROM user WHERE username = '$username'";
        $result = mysqli_query($db, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userId = $row['id'];
            
   
            $insertQuery = "INSERT INTO borrow (userid, bookid) VALUES ('$userId', '$bookId')";
            if (mysqli_query($db, $insertQuery)) {
                echo "Book borrowed successfully.";
            } else {
                echo "Error borrowing book: " . mysqli_error($db);
            }
        } else {
            echo "Error retrieving user ID.";
        }

        $updateQuery = "UPDATE books SET no_of_copy = no_of_copy - 1 WHERE book_id = '$bookId'";
        mysqli_query($db, $updateQuery);

    } else {
        echo "Book is out of stock.";
    }

    // Redirect back to the book list page
    header("Location: userbook2.php");
    exit();
}

mysqli_free_result($result);
?>
