<?php
include "headeradmin.php";
?>


<!DOCTYPE HTML>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Jost', sans-serif;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
            background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            height: 100vh;
        }

        table {
            background-color: lightgoldenrodyellow;
        }
    </style>
</head>

<body>
    <br>
    <?php
    include("DBConnection.php");
    $search = isset($_REQUEST["search"]) ? $_REQUEST["search"] : "";
	$query = "SELECT book_id, book_title, author, no_of_copy FROM books WHERE book_id LIKE '%$search%'";

    $result = mysqli_query($db, $query);
    if (mysqli_num_rows($result) > 0) {
    ?>

    <table border="2" align="center" cellpadding="12" cellspacing="">
        <tr>
            <th>No.</th>
            <th>Book Title</th>
            <th>Author</th>
			<th>No of copy</th>
            <th colspan="2">Actions</th>
        </tr>
        <?php 
        $counter = 1; // Initialize the counter variable
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $counter++; ?></td>
                <td><?php echo $row["book_title"];?></td>
                <td><?php echo $row["author"];?></td>
				<td><?php echo $row["no_of_copy"];?></td>
                <td><a href="edit_book.php?title=<?php echo $row["book_id"];?>">Edit</a></td>
                <td><a href="delete_book.php?title=<?php echo $row["book_id"];?>" onclick="return confirm('Are you sure you want to delete this book?')">Delete</a></td>
            </tr>
            <?php
        }
        ?>
    </table>

    <?php
    } else {
        echo "<center>No books found in the library with the name: $search</center>";
    }
    ?>
<br>
    <div style="text-align: center;">
        <a href="EnterBooks.php" style="text-decoration: none; padding: 10px 20px; background-color: lightgreen; color: white; font-weight: bold;">Add Book</a>
    </div>

</body>
</html>