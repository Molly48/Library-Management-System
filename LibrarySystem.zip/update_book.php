<?php
include("DBConnection.php");

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $bookTitle = $_POST['book_title'];
    $author = $_POST['author'];
    $noOfCopy = $_POST['no_of_copy'];

    $query = "UPDATE books SET book_title = '$bookTitle', author = '$author', no_of_copy = '$noOfCopy' WHERE book_id = '$title'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "Book information updated successfully.";
        // Redirect to the display page after update
        header("Location: DisplayBooks.php");
        exit;
    } else {
        echo "Error updating book information.";
    }
} else {
    echo "Invalid request.";
}
?>
