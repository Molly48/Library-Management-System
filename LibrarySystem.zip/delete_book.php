<?php
include("DBConnection.php");

if(isset($_GET['title'])) {
    $title = $_GET['title'];

    $query = "DELETE FROM books WHERE book_id = '$title'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "Book deleted successfully.";
        // Redirect to the display page after deletion
        header("Location: DisplayBooks.php");
        exit;
    } else {
        echo "Error deleting book.";
    }
} else {
    echo "Invalid book title.";
}
?>
