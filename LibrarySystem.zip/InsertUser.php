<?php
include "headeradmin.php";
?>

<!DOCTYPE HTML>
<html>
<head>
    <center>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Jost', sans-serif;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
            background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            height: 100vh; 
        }

        table {
            background-color: lightgoldenrodyellow;
        }

        h1 {
            color: white;
        }
    </style>
</head>

<body>
    <?php
    include("DBConnection.php");

    $username = isset($_POST["username"]) ? $_POST["username"] : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";

    $query = "INSERT INTO user (username, password) VALUES ('$username', '$password')";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "<h1>User inserted successfully</h1>";
        echo "<a href='DisplayUser.php'>Click here for user information</a>";
    } else {
        echo "<h3>Error occurred while inserting user information</h3>";
    }
    ?>

</body>
</center>
</html>
