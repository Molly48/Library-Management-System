<?php
  include "headeradmin.php";
?>

<!DOCTYPE HTML>
<html>

<center>
<style>

  body {
        margin: 0;
        padding: 0;
        font-family: 'Jost', sans-serif;
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        background-image: url('https://images.indianexpress.com/2021/06/Untitled-design-4-1.png');
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        height: 100vh; 
    }

	table {
		background-color: lightgoldenrodyellow;
	}

	h1 {
		color: white;
	}
</style>

<body>
	
<?php
include("DBConnection.php");

$book_id = isset($_POST["book_id"]) ? $_POST["book_id"] : "";
$book_title = isset($_POST["book_title"]) ? $_POST["book_title"] : "";
$author = isset($_POST["author"]) ? $_POST["author"] : "";
$no_of_copy = isset($_POST["no_of_copy"]) ? $_POST["no_of_copy"] : "";

$query = "INSERT INTO books (book_id, book_title, author, no_of_copy) VALUES ('$book_id', '$book_title', '$author' , '$no_of_copy')"; 
$result = mysqli_query($db, $query);

if ($result) {
    echo "<h1>Book inserted successfully</h1>";
    echo "<a href='DisplayBooks.php'>Click here for book information</a>";
} else {
    echo "<h3>Error occurred while inserting book information</h3>";
}
?>


</body>
</center>
</html>
